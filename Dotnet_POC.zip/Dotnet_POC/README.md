# jwt-aspnetcore
Implementing JWT Authentication in ASP.NET Core 5

To clone this repository, create a folder in your computer where you would like the source code tpo be downloaded. Now you can clone the source code repository using the following command:

git clone https://github.com/joydipkanjilal/jwt-aspnetcore.git 



To run this application in your computer, follow the steps outlined below to start the application:

1. Launch Visual Studio in your system
2. Click File -> Open -> Project/Solution...
3. Select the .sln file and click Open
4. Once all files have been loaded, build the solution
5. Press F5 to start the application
